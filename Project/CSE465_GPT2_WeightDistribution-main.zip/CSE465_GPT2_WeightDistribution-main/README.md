# CSE465_GPT2_WeightDistribution
Here, we look at the weight distribution of GPT 2 before and after training, layer by layer, using a histogram.
